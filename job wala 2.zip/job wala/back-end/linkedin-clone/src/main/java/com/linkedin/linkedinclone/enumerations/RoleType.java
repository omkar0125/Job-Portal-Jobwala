package com.linkedin.linkedinclone.enumerations;

public enum RoleType {
    ADMIN,
    PROFESSIONAL
}
