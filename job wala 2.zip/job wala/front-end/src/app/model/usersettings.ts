export class UserSettings{
    id: number;
    currentPassword: string;
    newPassword: string;
    passwordConfirm: string;
    currentUsername: string;
    newUsername: string;
}